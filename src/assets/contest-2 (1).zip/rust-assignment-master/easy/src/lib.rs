use std::collections::HashMap;

pub type AccountId = String;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Account {
    pub owner_name: String,
    pub balance: u64,
    pub is_frozen: bool,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Instruction {
    CreateAccount {
        account_id: AccountId,
        owner_name: String,
    },
    Deposit {
        account_id: AccountId,
        amount: u64,
    },
    Transfer {
        from: AccountId,
        to: AccountId,
        amount: u64,
    },
    Freeze {
        account_id: AccountId,
    },
    Unfreeze {
        account_id: AccountId,
    },
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum LedgerError {
    AccountAlreadyExists,
    AccountNotFound,
    AccountFrozen,
    InsufficientFunds,
    InvalidAmount,
}

pub struct Ledger {
    accounts: HashMap<AccountId, Account>,
}

impl Ledger {
    pub fn new() -> Self {
        todo!("create an empty Ledger")
    }

    pub fn process_instruction(&mut self, instruction: Instruction) -> Result<(), LedgerError> {
        let _ = instruction;
        let _ = &self.accounts;

        todo!("match on Instruction and update ledger state")
    }

    pub fn get_account(&self, account_id: &str) -> Option<&Account> {
        let _ = account_id;
        let _ = &self.accounts;

        todo!("return the account for this id, if it exists")
    }
}
